<?php

namespace Sober\Models;

use Noodlehaus\AbstractConfig;

class ConfigNoFile extends AbstractConfig
{

}
