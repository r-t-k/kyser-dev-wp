### 1.1.0: 04 August 2018
* Add extended-cpts support
* Update dependencies

### 1.0.6: 28th Janurary 2018
* Add if function_exists for add_action

### 1.0.5: 27th August 2017
* If user is using Sage, default path to be app/models/

### 1.0.4: 06th February 2017
* Add PHP and YML file support

### 1.0.2: 05th January 2017
* Fix multiple config per files bug
* Refactor and chain methods

### 1.0.1: 03nd January 2017
* Multidimensional array support added for json files
* Include recursive support for $path subfolders

### 1.0.0: 02nd January 2017
* Release Models
