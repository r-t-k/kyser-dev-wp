<?php
return [
    [
        'type' => 'category',
        'name' => 'genre',
        'links' => 'book',
    ],
    [
        'type' => 'tag',
        'name' => 'author',
        'links' => 'book',
    ],
];