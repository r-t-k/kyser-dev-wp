<?php
return [
    'type' => 'post-type',
    'name' => 'book',
];