<?php
return [
    'type' => 'taxonomy',
    'name' => 'genre',
];